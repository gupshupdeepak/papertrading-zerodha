document.getElementById("show").addEventListener("click", async () => {
  const tabs = await browser.tabs.query({active:true, currentWindow:true});
  if (!tabs[0] || !tabs[0].url || !tabs[0].url.startsWith("https://kite.zerodha.com/")) {
    document.querySelector("p").textContent = "Open https://kite.zerodha.com/ in the active tab first.";
    return;
  }
  try {
    await browser.tabs.sendMessage(tabs[0].id, {type:"TOGGLE_PANEL"});
    window.close();
  } catch (e) {
    document.querySelector("p").textContent = "Please reload the Kite tab and try again.";
  }
});