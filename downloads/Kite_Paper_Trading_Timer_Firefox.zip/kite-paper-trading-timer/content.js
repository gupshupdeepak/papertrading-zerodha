(() => {
  if (window.__kptLoaded) return;
  window.__kptLoaded = true;

  const parsePrice = (s) => {
    if (!s) return null;
    const cleaned = String(s).replace(/,/g, "").match(/-?\d+(?:\.\d+)?/);
    if (!cleaned) return null;
    const n = Number(cleaned[0]);
    return Number.isFinite(n) && n > 0 ? n : null;
  };

  // ---------- Price detection (runs in EVERY frame; Kite charts live in an iframe) ----------
  const NUM_RE = /^[₹$]?\s*\d{1,3}(?:,\d{2,3})*(?:\.\d{1,4})?$|^\d{1,7}(?:\.\d{1,4})?$/;
  const isTop = window.top === window;

  function collectCandidates() {
    const out = [];
    const vw = window.innerWidth, vh = window.innerHeight;
    if (vw < 150 || vh < 100) return out;
    const frameArea = vw * vh;
    const seen = new Set();
    const consider = (el, text, bonus) => {
      if (!el || seen.has(el)) return;
      text = (text || "").trim();
      if (!NUM_RE.test(text)) return;
      if (el.closest && el.closest("#kpt-root")) return;
      const r = el.getBoundingClientRect();
      if (r.width < 6 || r.height < 6 || r.bottom < 0 || r.top > vh || r.right < 0 || r.left > vw) return;
      const st = getComputedStyle(el);
      if (st.display === "none" || st.visibility === "hidden" || Number(st.opacity) === 0) return;
      const price = parsePrice(text);
      if (price === null) return;
      seen.add(el);
      let score = bonus;
      // Current-price label on the axis: coloured background, hugging the right edge.
      const bg = st.backgroundColor || "";
      const m = bg.match(/rgba?\(\s*(\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);
      if (m && (m[4] === undefined || Number(m[4]) > 0.3)) score += 600;
      if (r.right > vw * 0.75) score += 200 - Math.abs(vw - r.right);
      else score -= 100;
      score += Math.min(300, frameArea / 5000);   // prefer the big chart frame
      out.push({price, score, text});
    };
    // a) elements whose class/id hints at a price label (ChartIQ / TradingView / Kite)
    try {
      document.querySelectorAll('[class*="price" i],[class*="last" i],[class*="ltp" i],[class*="current" i],[class*="label" i],[class*="hu-" i],[class*="value" i],[class*="legend" i],[class*="ohlc" i],[id*="price" i]')
        .forEach(el => { if (el.children.length === 0) consider(el, el.textContent, 400); });
    } catch (e) {}
    // b) every visible leaf text node that is purely a number
    const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
    let n = 0;
    while (walker.nextNode() && n++ < 20000) {
      const node = walker.currentNode;
      consider(node.parentElement, node.nodeValue, 0);
    }
    // b2) OHLC legend text such as "C 24,350.55" / "Close 24350.55" (TradingView/ChartIQ style headers)
    try {
      document.querySelectorAll("span,div,li,td,b,strong").forEach(el => {
        if (el.closest("#kpt-root") || seen.has(el)) return;
        const tx = (el.textContent || "").trim();
        if (tx.length > 80 || el.children.length > 8) return;
        const mm = tx.match(/(?:^|[\s(])(?:C|Close)\s*[:=]?\s*₹?\s*(\d[\d,]*(?:\.\d+)?)(?![\d.])/);
        if (!mm) return;
        const r = el.getBoundingClientRect();
        if (r.width < 4 || r.height < 4) return;
        const p = parsePrice(mm[1]);
        if (p) { seen.add(el); out.push({price: p, score: 700 + Math.min(300, frameArea / 5000), text: mm[0].trim(), via: "legend"}); }
      });
    } catch (e) {}
    // c) page title fallback (some chart pages put the live price in the title)
    const t = (document.title || "").match(/(\d[\d,]*\.\d+)/);
    if (t) { const p = parsePrice(t[1]); if (p) out.push({price: p, score: 50 + frameArea / 20000, text: t[1]}); }
    return out;
  }


  // ---------- Instrument detection ----------
  const BAD_NAMES = /^(chart|buy|sell|kite|zerodha|nse|bse|nfo|mcx|cds|bfo|fno|options?|futures?|indicators?|compare|alerts?|trade|orders?|holdings|positions|funds|watchlist|search|loading|undo|redo|settings|fullscreen|d|w|m|1d|1w|1m)$/i;
  function cleanName(t) {
    t = decodeURIComponent((t || "").replace(/\+/g, " ")).replace(/\s+/g, " ").trim();
    return t;
  }
  function collectInstruments() {
    const out = [];
    const add = (name, score, via) => {
      name = cleanName(name);
      if (!name || name.length < 2 || name.length > 40 || /^[\d.,\s]+$/.test(name) || BAD_NAMES.test(name)) return;
      out.push({name, score, via});
    };
    // a) URL: Kite chart URLs look like /chart/web/<lib>/<segment>/<SYMBOL>/<token>
    try {
      const segs = location.pathname.split("/").filter(Boolean);
      const last = segs.length - 1;
      if (segs.length >= 3 && /^\d+$/.test(segs[last])) add(segs[last - 1], 1000, "url");
      const q = new URLSearchParams(location.search);
      for (const k of ["symbol", "tradingsymbol", "instrument", "ticker"]) if (q.get(k)) add(q.get(k), 950, "url-q");
    } catch (e) {}
    // b) legend header such as "NIFTY 50 · 5 · NSE"  or  "RELIANCE, 5, NSE"
    try {
      document.querySelectorAll("span,div,h1,h2,h3,a,b,strong,p").forEach(el => {
        if (el.closest("#kpt-root")) return;
        const tx = (el.textContent || "").trim();
        if (tx.length < 4 || tx.length > 60) return;
        const m = tx.match(/^([A-Za-z0-9&][A-Za-z0-9&\-_. ]{1,28}?)\s*[·•,|]\s*(?:\d+\s*[mhdwMD]?|[DWM]|\d+(?:min|hour|day|week)\w*)\b/);
        if (m) add(m[1], 800, "legend");
      });
    } catch (e) {}
    // c) elements whose class/id says symbol / instrument
    try {
      document.querySelectorAll('[class*="symbol" i],[class*="instrument" i],[class*="tradingsymbol" i],[class*="scrip" i],[id*="symbol" i],[class*="chart-title" i],[class*="ticker" i]')
        .forEach(el => {
          if (el.closest("#kpt-root") || el.children.length > 3) return;
          const r = el.getBoundingClientRect();
          if (r.width < 4 || r.height < 4) return;
          const t = (el.textContent || "").trim();
          if (/^[A-Za-z0-9&][A-Za-z0-9&\-_. ]{1,38}$/.test(t)) add(t, 600, "class");
        });
    } catch (e) {}
    // d) page title
    try {
      const t = (document.title || "").replace(/^[^A-Za-z0-9&]+/, "");
      const first = t.split(/\s[-–—|]\s|\s·\s/)[0].replace(/\s+[\d,]+\.\d+.*$/, "");
      add(first, 200, "title");
    } catch (e) {}
    return out;
  }

  function textAtPoint(x, y) {
    for (const el of document.elementsFromPoint(x, y)) {
      if (el.closest && el.closest("#kpt-root")) continue;
      const txt = (el.textContent || "").trim();
      if (txt.length < 20 && NUM_RE.test(txt)) return parsePrice(txt);
    }
    return null;
  }

  // Frame-side message handling. Parent asks -> frame answers + forwards to its own child frames.
  let pickHandler = null;
  function stopPick() { if (pickHandler) { document.removeEventListener("click", pickHandler, true); pickHandler = null; } }
  window.addEventListener("message", (ev) => {
    const d = ev.data;
    if (!d || d.kpt !== "REQ_PRICES") return;
    const cs = collectCandidates();
    try { ev.source.postMessage({kpt: "RES_PRICES", id: d.id, cands: cs, insts: collectInstruments(), info: {url: location.href.slice(0, 80), n: cs.length, top: cs.slice().sort((a,b)=>b.score-a.score).slice(0,3).map(c=>c.text+(c.via?"("+c.via+")":""))}}, "*"); } catch (e) {}
    for (let i = 0; i < window.frames.length; i++) {
      try { window.frames[i].postMessage({kpt: "REQ_PRICES", id: d.id}, "*"); } catch (e) {}
    }
    // forward child answers upward
  });
  window.addEventListener("message", (ev) => {
    const d = ev.data;
    if (!d || d.kpt !== "RES_PRICES" || isTop) return;
    try { window.parent.postMessage(d, "*"); } catch (e) {}
  });
  window.addEventListener("message", (ev) => {
    const d = ev.data;
    if (!d || d.kpt !== "PICK") return;
    stopPick();
    pickHandler = (e) => {
      const p = textAtPoint(e.clientX, e.clientY);
      stopPick();
      try { window.top.postMessage({kpt: "PICKED", id: d.id, price: p}, "*"); } catch (x) {}
      e.preventDefault(); e.stopPropagation();
    };
    document.addEventListener("click", pickHandler, true);
    for (let i = 0; i < window.frames.length; i++) {
      try { window.frames[i].postMessage({kpt: "PICK", id: d.id}, "*"); } catch (e) {}
    }
  });

  if (!isTop) return;   // only the top frame gets the floating panel


  const $ = (id) => document.getElementById(id);
  const fmtTime = (ms) => new Date(ms).toLocaleTimeString([], {hour:"2-digit", minute:"2-digit", second:"2-digit"});
  const money = (n) => Number(n).toLocaleString("en-IN", {maximumFractionDigits:4});
  let trades = [];
  let activeTradeId = null;
  let tickHandle = null;

  const root = document.createElement("section");
  root.id = "kpt-root";
  root.innerHTML = `
    <div id="kpt-head"><span id="kpt-title">Paper Trade Timer</span><div><button id="kpt-min" title="Minimize">−</button><button id="kpt-hide" title="Hide">×</button></div></div>
    <div id="kpt-body">
      <label for="kpt-instrument">Instrument / symbol</label>
      <input id="kpt-instrument" placeholder="e.g. NIFTY 50, RELIANCE">
      <div class="kpt-row">
        <div><label for="kpt-side">Direction</label><select id="kpt-side"><option value="BUY">BUY</option><option value="SELL">SELL</option></select></div>
        <div><label for="kpt-duration">Duration</label><select id="kpt-duration"><option value="5">5 min</option><option value="15">15 min</option><option value="25" selected>25 min</option><option value="30">30 min</option><option value="45">45 min</option><option value="60">60 min</option><option value="custom">Custom</option></select></div>
      </div>
      <div id="kpt-custom-wrap" style="display:none"><label for="kpt-custom">Custom duration (minutes)</label><input id="kpt-custom" type="number" min="1" max="1440" value="25"></div>
      <label for="kpt-entry">Entry price</label><input id="kpt-entry" type="number" min="0.0001" step="any" placeholder="Enter entry price">
      <div class="kpt-buttons"><button class="kpt-btn secondary" id="kpt-capture-entry" type="button">Detect chart price</button><button class="kpt-btn" id="kpt-start" type="button">Start trade</button></div>
      <div id="kpt-clock">25:00</div><div id="kpt-status" aria-live="polite">Ready for a paper trade</div>
      <label for="kpt-exit">Exit price (enter when timer ends)</label><input class="kpt-close-price" id="kpt-exit" type="number" min="0.0001" step="any" placeholder="Exit price">
      <div class="kpt-buttons"><button class="kpt-btn secondary" id="kpt-capture-exit" type="button">Detect chart price</button><button class="kpt-btn" id="kpt-close-trade" type="button">Close trade</button><button class="kpt-btn warn" id="kpt-reset" type="button">Reset</button></div>
      <div id="kpt-result">P&amp;L will appear here.</div>
      <div class="kpt-buttons"><button class="kpt-btn secondary" id="kpt-export" type="button">Export CSV</button><button class="kpt-btn warn" id="kpt-clear" type="button">Clear history</button><button class="kpt-btn secondary" id="kpt-debug" type="button">Debug</button></div>
      <div id="kpt-history"><h4>Recent trades</h4><div id="kpt-trades">No trades saved yet.</div></div>
      <div class="kpt-small">Paper-trading journal only — no orders are placed. When the timer ends the exit price is detected and the trade closes automatically. Detect chart price looks for a visible price label near the chart’s right edge; if it cannot identify one, click the price on the chart when prompted, or enter it manually.</div>
    </div>`;
  document.documentElement.appendChild(root);

  browser.storage.local.get("kptTrades").then(data => {
    trades = Array.isArray(data.kptTrades) ? data.kptTrades : [];
    renderHistory();
    const open = trades.filter(t => !t.exitTime).sort((a,b) => b.entryTime - a.entryTime)[0];
    if (open) {
      activeTradeId = open.id;
      $("kpt-instrument").value = open.instrument; $("kpt-side").value = open.side; $("kpt-entry").value = open.entryPrice;
      if (open.endTime <= Date.now()) {
        open.alerted = true;   // ended while page was closed: don't auto-detect a stale-time price
        $("kpt-clock").textContent = "00:00";
        $("kpt-status").textContent = "Timer ended while the page was closed — enter exit price.";
        $("kpt-result").textContent = "Press Detect chart price (current price) or type the exit price, then Close trade.";
      }
      if (tickHandle) clearInterval(tickHandle);
      tickHandle = setInterval(renderClock, 250);
      renderClock();
    }
  }).catch(() => {});
  const save = () => browser.storage.local.set({kptTrades:trades}).catch(() => {});

  function durationMs() {
    const val = $("kpt-duration").value === "custom" ? Number($("kpt-custom").value) : Number($("kpt-duration").value);
    return Math.max(1, Math.min(1440, Number.isFinite(val) ? val : 25)) * 60000;
  }
  function activeTrade() { return trades.find(t => t.id === activeTradeId && !t.exitTime); }
  function beep() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      [0, 0.25, 0.5].forEach(d => {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.frequency.value = 880; g.gain.value = 0.15;
        o.connect(g); g.connect(ctx.destination);
        o.start(ctx.currentTime + d); o.stop(ctx.currentTime + d + 0.15);
      });
      setTimeout(() => ctx.close().catch(() => {}), 1500);
    } catch (e) {}
  }
  function renderClock() {
    const t = activeTrade();
    if (!t) return;
    const remaining = Math.max(0, t.endTime - Date.now());
    const sec = Math.ceil(remaining / 1000);
    $("kpt-clock").textContent = `${String(Math.floor(sec/60)).padStart(2,"0")}:${String(sec%60).padStart(2,"0")}`;
    if (remaining <= 0) {
      $("kpt-status").textContent = "Timer finished.";
      if (t.alerted !== true) {
        t.alerted = true;
        save();
        beep();
        try { document.title = "⏰ Trade timer finished — " + document.title; } catch(e) {}
        $("kpt-result").textContent = `Timer ended at ${fmtTime(t.endTime)}. Detecting exit price…`;
        detectChartPrice().then(detectedExit => {
          if (t.exitTime) return;   // already closed manually meanwhile
          if (detectedExit !== null) {
            t.detectedExitPrice = detectedExit;
            closeTrade(t, detectedExit, true);
          } else {
            $("kpt-status").textContent = "Timer finished — exit price not detected.";
            $("kpt-result").textContent = `Timer ended at ${fmtTime(t.endTime)}. Chart price was not detected; enter the exit price and click Close trade.`;
            $("kpt-exit").focus({preventScroll:true});
            save();
          }
        });
      }
    } else {
      $("kpt-status").textContent = `Started ${fmtTime(t.entryTime)} • Ends ${fmtTime(t.endTime)}`;
    }
  }
  function renderHistory() {
    const el = $("kpt-trades");
    if (!trades.length) { el.textContent = "No trades saved yet."; return; }
    el.innerHTML = trades.slice().sort((a,b)=>b.entryTime-a.entryTime).slice(0,8).map(t => {
      const closed = !!t.exitTime;
      const pnl = closed ? ((t.side === "BUY" ? 1 : -1) * (t.exitPrice-t.entryPrice)) : null;
      return `<div class="kpt-trade"><strong>${escapeHtml(t.instrument)}</strong> ${t.side} @ ${money(t.entryPrice)}<br>${new Date(t.entryTime).toLocaleString()} • ${closed ? `Exit ${money(t.exitPrice)} • P&amp;L ${pnl>=0?"+":""}${money(pnl)} pts` : "OPEN"}</div>`;
    }).join("");
  }
  function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
  function selectedPrice() {
    const sel = window.getSelection()?.toString().trim();
    const p = parsePrice(sel);
    if (p === null) {
      $("kpt-status").textContent = "No selected price. Highlight a price on the Kite page or enter it manually.";
      return null;
    }
    return p;
  }
  // Ask every frame for price candidates, pick the best-scoring one.
  function detectPage() {
    return new Promise((resolve) => {
      const id = "kpt" + Math.random().toString(36).slice(2);
      const all = collectCandidates();
      const insts = collectInstruments();
      const infos = [{url: location.href.slice(0, 80) + " (top)", n: all.length, top: all.slice().sort((a,b)=>b.score-a.score).slice(0,3).map(c=>c.text), inst: insts.slice().sort((a,b)=>b.score-a.score).slice(0,3).map(i=>i.name+"("+i.via+")")}];
      window.__kptDebug = infos;
      const onMsg = (ev) => {
        const d = ev.data;
        if (d && d.kpt === "RES_PRICES" && d.id === id && Array.isArray(d.cands)) {
          for (const c of d.cands) if (c && Number.isFinite(c.price) && c.price > 0) all.push(c);
          if (Array.isArray(d.insts)) for (const i of d.insts) if (i && typeof i.name === "string" && i.name.length < 41) insts.push({name: i.name, score: Number(i.score) || 0, via: i.via});
          if (d.info) { d.info.inst = (d.insts || []).slice().sort((a,b)=>b.score-a.score).slice(0,3).map(i=>i.name+"("+i.via+")"); infos.push(d.info); }
        }
      };
      window.addEventListener("message", onMsg);
      for (let i = 0; i < window.frames.length; i++) {
        try { window.frames[i].postMessage({kpt: "REQ_PRICES", id}, "*"); } catch (e) {}
      }
      setTimeout(() => {
        window.removeEventListener("message", onMsg);
        all.sort((x, y) => y.score - x.score);
        insts.sort((x, y) => y.score - x.score);
        resolve({price: all.length ? all[0].price : null, instrument: insts.length ? insts[0].name : null});
      }, 500);
    });
  }
  const detectChartPrice = () => detectPage().then(r => r.price);
  let autoInstrument = "";
  async function fillInstrument() {
    const field = $("kpt-instrument");
    const {instrument} = await detectPage();
    // overwrite only if empty or the previous value was auto-filled (never clobber manual typing)
    if (instrument && (!field.value.trim() || field.value === autoInstrument)) {
      field.value = instrument; autoInstrument = instrument;
    }
    return instrument;
  }
  function pickPriceFromPage(target) {
    return new Promise((resolve) => {
      const id = "pick" + Math.random().toString(36).slice(2);
      $("kpt-status").textContent = "Click directly on the price label/number on the chart…";
      let done = false;
      const finish = (p) => { if (done) return; done = true; window.removeEventListener("message", onMsg); document.removeEventListener("click", localClick, true); resolve(p); };
      const onMsg = (ev) => { const d = ev.data; if (d && d.kpt === "PICKED" && d.id === id) finish(d.price); };
      const localClick = (e) => {
        if (e.target.closest && e.target.closest("#kpt-root")) return;
        const p = textAtPoint(e.clientX, e.clientY);
        if (p !== null) { e.preventDefault(); e.stopPropagation(); finish(p); }
      };
      window.addEventListener("message", onMsg);
      document.addEventListener("click", localClick, true);
      for (let i = 0; i < window.frames.length; i++) {
        try { window.frames[i].postMessage({kpt: "PICK", id}, "*"); } catch (e) {}
      }
      setTimeout(() => finish(null), 15000);
    });
  }
  async function capturePrice(target) {
    $("kpt-status").textContent = "Detecting instrument…";
    const page = await detectPage();
    const field = $("kpt-instrument");
    if (page.instrument && (!field.value.trim() || field.value === autoInstrument)) { field.value = page.instrument; autoInstrument = page.instrument; }
    let p = page.price;
    if (p !== null) {
      $(target).value = p;
      $("kpt-status").textContent = `${page.instrument ? page.instrument + ": " : ""}detected chart price ${money(p)}. Verify it matches the chart.`;
      return p;
    }
    if (!page.instrument && !field.value.trim()) $("kpt-status").textContent = "Instrument not detected — type it in.";
    const selected = selectedPrice();
    if (selected !== null) {
      $(target).value = selected;
      $("kpt-status").textContent = `Used highlighted price: ${money(selected)}.`;
      return selected;
    }
    p = await pickPriceFromPage(target);
    if (p !== null) {
      $(target).value = p;
      $("kpt-status").textContent = `Picked price: ${money(p)}.`;
      return p;
    }
    $("kpt-status").textContent = "Could not read a price (chart may be canvas-only). Type it manually.";
    return null;
  }
  $("kpt-debug").addEventListener("click", async () => {
    $("kpt-result").textContent = "Scanning frames…";
    await detectChartPrice();
    const info = window.__kptDebug || [];
    $("kpt-result").textContent = `Frames that responded: ${info.length}\n` + info.map(i => `• ${i.url}\n  candidates: ${i.n} ${i.top && i.top.length ? "→ " + i.top.join(" | ") : ""}\n  instrument: ${i.inst && i.inst.length ? i.inst.join(" | ") : "none"}`).join("\n");
  });
  $("kpt-capture-entry").addEventListener("click", () => capturePrice("kpt-entry"));
  $("kpt-capture-exit").addEventListener("click", () => capturePrice("kpt-exit"));
  $("kpt-duration").addEventListener("change", () => { $("kpt-custom-wrap").style.display=$("kpt-duration").value==="custom"?"block":"none"; if(!activeTrade()) $("kpt-clock").textContent=`${String(Math.floor(durationMs()/60000)).padStart(2,"0")}:00`; });

  $("kpt-start").addEventListener("click", async () => {
    if (!$("kpt-instrument").value.trim()) await fillInstrument();
    if (activeTrade()) { $("kpt-status").textContent="A trade is already running. Close it before starting another."; return; }
    const instrument=$("kpt-instrument").value.trim();
    const entryPrice=Number($("kpt-entry").value);
    if (!instrument) { $("kpt-status").textContent="Enter an instrument name."; $("kpt-instrument").focus(); return; }
    if (!Number.isFinite(entryPrice)||entryPrice<=0) { $("kpt-status").textContent="Enter a valid entry price."; $("kpt-entry").focus(); return; }
    const now=Date.now();
    const t={id:crypto.randomUUID(),instrument,side:$("kpt-side").value,entryPrice,entryTime:now,endTime:now+durationMs(),exitPrice:null,exitTime:null,durationMinutes:durationMs()/60000};
    trades.push(t); activeTradeId=t.id; save(); renderHistory(); renderClock();
    $("kpt-result").textContent=`Trade started at ${fmtTime(now)}.`;
    if(tickHandle) clearInterval(tickHandle);
    tickHandle=setInterval(renderClock,250);
  });
  function closeTrade(t, exitPrice, auto) {
    if (!t || t.exitTime) return;
    t.exitPrice=exitPrice; t.exitTime=Date.now(); t.actualDurationMs=t.exitTime-t.entryTime; t.autoClosed=!!auto;
    const pnl=(t.side==="BUY"?1:-1)*(exitPrice-t.entryPrice);
    const pct=(pnl/t.entryPrice)*100;
    activeTradeId=null;
    if(tickHandle) clearInterval(tickHandle); tickHandle=null;
    $("kpt-exit").value=exitPrice;
    $("kpt-clock").textContent="CLOSED";
    $("kpt-status").textContent=`${auto?"Auto-closed":"Closed"} ${fmtTime(t.exitTime)} — press Reset for a new trade`;
    $("kpt-result").textContent=`${pnl>=0?"PROFIT":"LOSS"}: ${pnl>=0?"+":""}${money(pnl)} points (${pct>=0?"+":""}${pct.toFixed(3)}%)\nEntry ${money(t.entryPrice)} → Exit ${money(exitPrice)}\nTimer target: ${t.durationMinutes} min • Actual: ${(t.actualDurationMs/60000).toFixed(1)} min`;
    save(); renderHistory();
  }
  $("kpt-close-trade").addEventListener("click", () => {
    const t=activeTrade();
    if (!t) { $("kpt-status").textContent="No open trade to close."; return; }
    const exitPrice=Number($("kpt-exit").value);
    if (!Number.isFinite(exitPrice)||exitPrice<=0) { $("kpt-status").textContent="Enter a valid exit price."; $("kpt-exit").focus(); return; }
    closeTrade(t, exitPrice, false);
  });
  $("kpt-reset").addEventListener("click", () => {
    const t=activeTrade();
    if (t) {
      if (!confirm("A trade is still running. Discard it and reset?")) return;
      trades = trades.filter(x => x.id !== t.id);
      activeTradeId = null; save(); renderHistory();
    }
    if (tickHandle) clearInterval(tickHandle); tickHandle = null;
    $("kpt-entry").value=""; $("kpt-exit").value="";
    $("kpt-clock").textContent=`${String(Math.floor(durationMs()/60000)).padStart(2,"0")}:00`;
    $("kpt-status").textContent="Ready for a paper trade";
    $("kpt-result").textContent="P&L will appear here.";
    try { document.title = document.title.replace(/^⏰ Trade timer finished — /, ""); } catch(e) {}
    autoInstrument = "";  // allow re-detection for whichever chart is open now
    $("kpt-instrument").value = "";
    fillInstrument().catch(() => {});
  });
  $("kpt-export").addEventListener("click", () => {
    const headers=["instrument","side","entry_price","entry_time","duration_minutes","target_exit_time","exit_price","actual_exit_time","pnl_points","pnl_percent","status"];
    const rows=trades.map(t=>{
      const closed=!!t.exitTime, pnl=closed?(t.side==="BUY"?1:-1)*(t.exitPrice-t.entryPrice):"";
      return [t.instrument,t.side,t.entryPrice,new Date(t.entryTime).toISOString(),t.durationMinutes,new Date(t.endTime).toISOString(),closed?t.exitPrice:"",closed?new Date(t.exitTime).toISOString():"",closed?pnl:"",closed?(pnl/t.entryPrice*100).toFixed(4):"",closed?"CLOSED":"OPEN"];
    });
    const csv=[headers,...rows].map(row=>row.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\r\n");
    const url=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8;"}));
    const a=document.createElement("a"); a.href=url; a.download="paper-trades.csv"; a.click(); URL.revokeObjectURL(url);
  });
  $("kpt-clear").addEventListener("click", () => {
    if(!confirm("Delete all saved paper trades? This cannot be undone.")) return;
    trades=[]; activeTradeId=null; if(tickHandle) clearInterval(tickHandle); tickHandle=null;
    save(); renderHistory(); $("kpt-clock").textContent="25:00"; $("kpt-status").textContent="History cleared."; $("kpt-result").textContent="P&L will appear here.";
  });
  $("kpt-min").addEventListener("click", () => $("kpt-body").style.display=$("kpt-body").style.display==="none"?"block":"none");
  $("kpt-hide").addEventListener("click", () => root.classList.add("kpt-hidden"));

  // Drag the panel by its header.
  const head=$("kpt-head"); let drag=null;
  head.addEventListener("pointerdown", e=>{
    if(e.target.closest("button")) return;
    const r=root.getBoundingClientRect(); drag={x:e.clientX-r.left,y:e.clientY-r.top};
    head.setPointerCapture(e.pointerId);
  });
  head.addEventListener("pointermove", e=>{
    if(!drag) return;
    root.style.left=Math.max(0,Math.min(window.innerWidth-root.offsetWidth,e.clientX-drag.x))+"px";
    root.style.top=Math.max(0,Math.min(window.innerHeight-60,e.clientY-drag.y))+"px";
    root.style.right="auto";
  });
  head.addEventListener("pointerup",()=>drag=null);
  browser.runtime.onMessage.addListener(msg=>{
    if(msg?.type==="TOGGLE_PANEL") root.classList.toggle("kpt-hidden");
  });
  renderClock();
  setTimeout(() => { fillInstrument().catch(() => {}); }, 2500);
})();